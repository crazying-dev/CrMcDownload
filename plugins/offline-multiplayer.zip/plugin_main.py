"""离线联机官方特权插件入口（随 bundle 下载、sha256 校验通过后由注册表加载）。"""

from offcraft.plugins.base import PLUGIN_API, PluginManifest

MANIFEST = PluginManifest(
    id="offline-multiplayer",
    name="离线联机",
    description="端到端加密的离线联机（按需下载的官方特权插件）。",
    version="1.2.0",
    api=PLUGIN_API,
    capabilities=("net.tunnel", "ui.log", "config.namespace", "ui.notice", "runtime.task"),
    official=True,
    detail="启用后可在插件页进入房间管理面板；引擎 offcraft_p2p 随本包提供。",
)


class OfflineMultiplayerPlugin:
    """特权插件句柄：``setup`` 记录受限上下文，``teardown`` 释放。

    真正的房间/隧道面板由宿主 UI（插件页卡片「进入」）承载；引擎经顶层包
    ``offcraft_p2p``（本包解包后进入 ``sys.path``）解析，不暴露给受限沙箱之外的宿主网络。
    """

    def __init__(self) -> None:
        self._ctx = None

    def setup(self, ctx) -> None:
        self._ctx = ctx
        ctx.log("INFO", "[offline-multiplayer] 特权插件已启用（net.tunnel）")

    def teardown(self) -> None:
        self._ctx = None


def create() -> OfflineMultiplayerPlugin:
    return OfflineMultiplayerPlugin()
